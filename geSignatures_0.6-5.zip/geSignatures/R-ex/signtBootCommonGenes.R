### Name: signtBootCommonGenes
### Title: Show common genes from bootstrap runs of geSignatureBoot.
### Aliases: signtBootCommonGenes
### Keywords: multivariate classif

### ** Examples

## see examples in geSignatureBoot



