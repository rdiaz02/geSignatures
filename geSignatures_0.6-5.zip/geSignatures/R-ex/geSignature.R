### Name: geSignature
### Title: Gene expression signature (for class prediction problem)
### Aliases: geSignature
### Keywords: multivariate classif

### ** Examples

data(golub) ## in multtest
golub.data <- t(golub)
glSignt <- geSignature(golub.data, golub.cl,
                       min.var.axis.cor = 0.75,
                       control =
                       geSignature.control(filter.threshold = 8))

print(glSignt, ndec = 8)
summary(glSignt)




