### Name: signtBootComponentsSummary
### Title: Summarize results of bootstrap runs
### Aliases: signtBootComponentsSummary
### Keywords: multivariate classif

### ** Examples

### see examples in geSignatureBoot



