### Name: geSignature.control
### Title: Set additional parameters of geSignature
### Aliases: geSignature.control
### Keywords: multivariate classif

### ** Examples

data(golub) ## in multtest
golub.data <- t(golub)
glSignt <- geSignature(golub.data, golub.cl,
                       min.var.axis.cor = 0.75,
                       control =
                       geSignature.control(filter.threshold = 8))




