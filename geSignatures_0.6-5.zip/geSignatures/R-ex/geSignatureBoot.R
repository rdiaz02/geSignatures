### Name: geSignatureBoot
### Title: Bootstrapping geSignature function
### Aliases: geSignatureBoot
### Keywords: multivariate classif

### ** Examples

data(golub) ## in multtest
golub.data <- t(golub)
## Set bootnumber to 5 so that it runs reasonably fast.
glSigntB <- geSignatureBoot(golub.data, golub.cl, bootnumber = 5)
signtBootCommonGenes(glSigntB)
signtBootComponentsSummary(glSigntB)




