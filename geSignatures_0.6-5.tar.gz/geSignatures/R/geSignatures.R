#####   Copyright (C) 2003, 2004  Ram�n D�az-Uriarte, rdiaz@ligarto.org

#####  This program is free software; you can redistribute it and/or
#####  modify it under the terms of the GNU General Public License
#####  as published by the Free Software Foundation; either version 2
#####  of the License, or (at your option) any later version.

#####  This program is distributed in the hope that it will be useful,
#####  but WITHOUT ANY WARRANTY; without even the implied warranty of
#####  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#####  GNU General Public License for more details.

#####  You should have received a copy of the GNU General Public License
#####  along with this program; if not, write to the Free Software
#####  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.



## vignettes!!


##RNGkind("Mersenne-Twister", "Inversion")
library(multtest) ## for mt.maxT
#library(class) ## for knn
#dyn.load("dlda.so") 


### The "use.dgesvd" is to prevent a documented problem with lapack;
### this problem can result in svd crashing when using dgesdd. This was 
### a problem with Debian GNU/Linux and the deb package for R-1.9.1.
### Now I link against Goto's BLAS, and this is no longer a problem
### I leave the code just in case.

#####use.dgesvd <- FALSE

#####if(use.dgesvd) {
#####    warning("prcomp substituted by prcomp.dgesvd")
#####    prcomp.dgesvd <- 
#####        function (x, retx = TRUE, center = TRUE, scale. = FALSE, tol = NULL) 
#####        { ## the error -12 problem with DGESDD
#####            x <- as.matrix(x)
#####            x <- scale(x, center = center, scale = scale.)
#####            s <- La.svd(x, method = "dgesvd")
#####            s$v <- t(s$vt)
#####            s$vt <- NULL
#####            if (!is.null(tol)) {
#####                rank <- sum(s$d > (s$d[1] * tol))
#####                if (rank < ncol(x)) 
#####                    s$v <- s$v[, 1:rank, drop = FALSE]
#####            }
#####            s$d <- s$d/sqrt(max(1, nrow(x) - 1))
#####            dimnames(s$v) <- list(colnames(x), paste("PC", seq(len = ncol(s$v)), 
#####                                                     sep = ""))
#####            r <- list(sdev = s$d, rotation = s$v)
#####            if (retx) 
#####                r$x <- x %*% s$v
#####            class(r) <- "prcomp"
#####            r
#####        }
#####    prcomp <- prcomp.dgesvd
    
#####}

## The following are internal functions; use namespaces to "hide" them.zz

dlda <- function (ls, cll, ts) {
    ## does dlda; returns the predictions;
    ## ls: matrix of covars; subjects by genes;
    ## cll an integer, starting at 0
    ## ts: test-set matrix of covars
    ## Not used directly anymore
    ls <- as.matrix(ls)
    ts <- as.matrix(ts)
    .C("dlda", as.double(ls), as.integer(cll),
       as.integer(as.vector(table(cll))), as.double(t(ts)),
       as.integer(max(cll) - min(cll) + 1), as.integer(length(cll)),
       as.integer(ncol(ls)), as.integer(nrow(ts)),
       predictions = as.integer(rep(-9, nrow(ts))), PACKAGE = "geSignatures")$predictions
}
 

dlda.pred.error <- function(ls, cll, nk) {
    if(!is.matrix(ls)) ls <- as.matrix(ls) 
    if(!is.matrix(cll)) cll <- as.matrix(cll)
    .C("dldaPredError", as.double(ls), as.integer(cll), as.integer(nk),
       as.double(t(ls)),
       as.integer(cll), as.integer(max(cll) + 1), as.integer(length(cll)),
       as.integer(ncol(ls)), as.integer(nrow(ls)),
       PredError = double(1), PACKAGE = "geSignatures")$PredError
}



dlda.pred.newdata.error <- function(ls, cll, newcovar, newcll, nk, ...) {
    if(!is.matrix(ls)) ls <- as.matrix(ls)
    if(!is.matrix(cll)) cll <- as.matrix(cll)
    if(!is.matrix(newcovar)) newcovar <- as.matrix(newcovar)
    if(!is.matrix(newcll)) newcll <- as.matrix(newcll)
    .C("dldaPredError", as.double(ls), as.integer(cll),as.integer(nk),
       as.double(t(newcovar)),
       as.integer(newcll), as.integer(max(cll) + 1), as.integer(length(cll)),
       as.integer(ncol(ls)), as.integer(nrow(newcovar)),
       PredError = double(1), PACKAGE = "geSignatures")$PredError
}


knn.pred.newdata.error <- function(ls, cll, newcovar, newcll, k.knn,  ...) {
    ## if ls == newcovar AND cll == newcll, then
    ## we are asking for resubstitution. So use knn.cv
    ## to avoid getting always a 0. (We only use this function
    ## to rank genes, not to obtain unbiased estimates of error rate).
    if(identical(ls, newcovar)&identical(cll, newcll)){
        newcovar <- as.matrix(newcovar)
        predicted <- knn.cv(newcovar, newcll, k = k.knn)
    }
    else{
        ls <- as.matrix(ls)
        newcovar <- as.matrix(newcovar)
        predicted <- knn(ls, newcovar, cll, k = k.knn)
    }
    sum(predicted != newcll)/length(newcll)
}


customSVD <- function(x) { 
    if (is.numeric(x)) 
        storage.mode(x) <- "double"
    n <- nrow(x)
    p <- ncol(x)
    np <- min(n, p)
    u <- matrix(0, n, np)
    v <- matrix(0, np, p)

##    xx <<- x: to reproduce dgesdd crashes
    
#####    if(use.dgesvd) 
#####        res <- .Call("La_svd", "S", "S", x, double(np), 
#####                 u, v, "dgesvd", PACKAGE = "base")
#####    else ## if no problems with DGESDD
    res <- .Call("La_svd", "S", "", x, double(np), 
                 u, v, "dgesdd", PACKAGE = "base") 
        
    res <- res[c("d", "vt")]
    res$vt <- res$vt[1:min(p, np), , drop = FALSE]
    return(res)
}


customPrcomp <- function(x, threshold.var = 0) {
    if(!is.matrix(x)) x <- as.matrix(x)
    s <- customSVD(x)
    s.var <- s$d^2
    s.cum <- s.var[1]/sum(s.var)
    if(s.cum > threshold.var) rx <- x %*% t(s$v)[,1] ## scores on 1st axis
    else rx <- rep(NA, dim(x)[1]) 
    return(c(s.cum, rx))
}


internal.cv.pred.error <- function(previous.signature,
                                   current.covar, cll, knumber = 5,
                                   method = "dlda",
                                   k.knn = 1) {
    ## CV error, recalculating components
    N <- length(cll)

    f2 <- function(index.select, cll) {
        produce.cv.sample <- FALSE
        tmp2 <- table(index.select, cll)
        for(mm in 1:knumber) {
            tmp3 <- as.vector(apply(tmp2[-mm,  , drop = FALSE], 2, sum))
                if((length(tmp3) < 2) | (min(tmp3) < 1)) {
                    produce.cv.sample <- TRUE
                    break
                }
        }
        return(produce.cv.sample)
    }

    if(method == "dlda") internal.pred.newdata.error <-
        dlda.pred.newdata.error
    else if(method == "knn") internal.pred.newdata.error <-
        knn.pred.newdata.error
    else stop("For now method can only be dlda or knn")

    ## Use CV to examine prediction error
    prediction.error <- rep(-9, knumber)

    produce.cv.sample <- TRUE
    while(produce.cv.sample) {
        index.select <-
            sample(rep(1:knumber, length = N), N,
                   replace = FALSE)## Code from Venables & Ripley, S Programming, p. 175.
        ## Make sure at least two classes in the training sets
        produce.cv.sample <- f2(index.select, cll)
    }

    for(sample.number in 1:knumber) {
        cv.train <- current.covar[index.select != sample.number,,
                                  drop = FALSE]
        cv.test <-
            current.covar[index.select == sample.number,,
                       drop = FALSE]
        cv.train.labels <- cll[index.select != sample.number]

        cv.train <- scale(cv.train, center = TRUE,
                          scale = FALSE)
        cv.test <- scale(cv.test,
                         center =
                         attributes(cv.train)$"scaled:center",
                         scale = FALSE)
        s <- customSVD(cv.train)
        scores.train <- cv.train %*% t(s$v)[, 1]
        scores.test <- cv.test %*% t(s$v)[, 1]

        train.covariates <-
            cbind(previous.signature[index.select != sample.number,,
                                       drop = FALSE],
                  scores.train)
        test.covariates <-
            cbind(previous.signature[index.select == sample.number,,
                                       drop = FALSE],
                  scores.test)
        prediction.error[sample.number] <-
            internal.pred.newdata.error(ls = train.covariates,
                                        cll = cv.train.labels,
                                        newcovar = test.covariates,
                                        newcll = cll[index.select == sample.number],
                                        nk = as.vector(table(cv.train.labels)),
                                        k.knn = k.knn)
    }
    return(c(mean(prediction.error), sqrt(var(prediction.error)/knumber)))
}

### Probably up to here not exported in namespace. zz




####################  Bootstrap code    ####################3


### To do:
### explain difference between mean.percentage and overlap.genes
### table genes: table.genes in common.genes? make the current common.genes
### and internal function and prepare a new one: talbe signatures?
### summary of number of signatures and number of genes, and number of genes per
### signature (but by signature position; i.e., 1st sign, etc).

### CommonGenes y ComponentSummary should take an object of class "geSigntB"
### and deal with it directly.


geSignatureBoot <- function(data, y, bootnumber = 200,
                                     method = "dlda",
                                     freq.threshold = 0.5,
                                     k.knn = 1,
                                     knumber = 5,...) {
    control <- geSignature.control(knumber = knumber, k.knn = k.knn,...)
    wholeSampleSignt <-
        geSignature(data, y, method = method, control = control, ...)

    genesWholeSample <- unlist(wholeSampleSignt$components.with.genes)
    if (!length(genesWholeSample))
        stop("There are no signatures")
    else
        length.genesWholeSample <- length(genesWholeSample)
    
    N <- length(y)
    pred.array <- matrix(nrow = N, ncol = bootnumber)
    bootstrapped.models <- list()

    mean.percentage <- 0
    overlap.genes <- 0

   
    
    cat("\n\n\n ### Starting bootstrap samples \n")

    for (bootindex in 1:bootnumber) {
        ### Steps are:
        ##      1. Get bootstrap sample
        ##      2. Get signature from bootstrap sample
        ##      3. Obtain scores (from PC eigenvectors found in step 2)
        ##         of subjects not in bootstrap sample
        ##      4. Generate predictions for those subjects not in
        ##         bootstrap sample (then used to obtain the "leave-one-
        ##         out-bootstrap" error
        cat("\n     ..........  bootstrap sample", bootindex, "\n")
        
#### This part should be parallelizable zzz

        sample.again <- TRUE
        while(sample.again) {
            bootsample <- unlist(tapply(1:N,  y,
                                        function(x)
                                        sample(x, size = length(x),
                                               replace = TRUE)))
            ## sure, this isn't the fastest, but will do for now.
            nobootsample <- setdiff(1:N, bootsample)
            if(!length(nobootsample))
                sample.again <- TRUE
            else sample.again <- FALSE
        }
        ## this is an ugly hack to prevetn nobootsamples
        ## of size 0.
        
        train.data <- data[bootsample, , drop = FALSE]
        test.data <- data[nobootsample, , drop = FALSE]
        train.class <- y[bootsample]
        test.class <- y[nobootsample]
        train.data <- scale(train.data, center = TRUE, scale = FALSE)        
        test.data <- scale(test.data,
                       center = attributes(train.data)$"scaled:center",
                       scale = FALSE)

        bootSampleSignt <-
            geSignature(train.data, train.class, method = method, control = control, ...)
        
        num.scores <- length(bootSampleSignt$components.with.genes)
        scores.test  <- matrix(ncol = num.scores, nrow = nrow(test.data))
        for (i in 1:num.scores) {
            genes <- bootSampleSignt$components.with.genes[[i]]
            if(length(genes) == 1) {## no pca for this signature
                scores.test[, i]  <- test.data[, genes]
            }
            else { ##eigenvectors, etc
#####                if(use.dgesvd)
#####                    s <- La.svd(train.data[, genes], nu = 0, method = "dgesvd")
#####                else
                s <- La.svd(train.data[, genes], nu = 0)
                scores.test[, i]  <- test.data[, genes] %*% t(s$v)[, 1]
            }
        }
        ## out-of-bag predictions
        if (method == "dlda") {
##            browser()
            pred.array[nobootsample, bootindex] <-
                .C("dlda", as.double(bootSampleSignt$components.scores), as.integer(train.class),
                   as.integer(as.vector(table(train.class))), as.double(t(scores.test)),
                   as.integer(max(train.class) - min(train.class) + 1),
                   as.integer(N),
                   as.integer(ncol(scores.test)), as.integer(nrow(scores.test)),
                   predictions = as.integer(rep(-9, nrow(scores.test))), PACKAGE = "geSignatures")$predictions
        }
        else if (method == "knn") {
            pred.array[nobootsample, bootindex] <-
                as.numeric(as.character(knn(bootSampleSignt$components.scores, scores.test, train.class, k = k.knn)))
        }
        bootstrapped.models[[bootindex]] <- bootSampleSignt

        recovered.genes.in <- unlist(bootSampleSignt$components.with.genes)
        length.recovered.genes.in <- length(recovered.genes.in)
        length.intersect <- length(intersect(recovered.genes.in, genesWholeSample))
        percentage <- length.intersect/(length.genesWholeSample+length.recovered.genes.in-length.intersect)
        if(length.recovered.genes.in != 0)
            overlap.genes.in <- length.intersect/sqrt(length.recovered.genes.in*length.genesWholeSample)
        else
            overlap.genes.in <- 0
        
        mean.percentage <- mean.percentage + percentage
        overlap.genes <- overlap.genes + overlap.genes.in        
    }

    mean.percentage <- mean.percentage/bootnumber
    overlap.genes <- overlap.genes/bootnumber
    
    recovered.genes.out <- common.genes(bootstrapped.models, freq.threshold)
    if(length(recovered.genes.out))
        overlap.genes.out <- length(intersect(recovered.genes.out, genesWholeSample))/
                            sqrt(length(recovered.genes.out)*length.genesWholeSample)        
    else
        overlap.genes.out <- 0

    ubiquitous.genes <- common.genes(bootstrapped.models, freq.threshold = 1)
    
    ############## The .632+ estimate of prediction error ##################
    ##      one:         \hat{Err}^{(1)} in Efron & Tibshirani, 1997, p. 550,
    ##                   or leave-one-out bootstrap error.  
    ##      resubst:     \bar{err}, the apparent error rate, resubstitution rate,
    ##                   or "in sample" error rate.
    ##      full.pred:   the "in sample" prediction from full model; only used
    ##                   to obtain gamma.
    ##      gamma:       gamma in p. 552
    ##      r:           R in p. 552 (bounding in [0, 1]).
    ##      err632:      the .632 error
    ##      errprime:    the one prime; \hat{Err}^{(1)}' 
    ##      err:         the .632+ error
    
    ## This is how I find one
    
    one <- mean(apply(cbind(pred.array, y), 1,
                           function(x) {mean(x[-(bootnumber + 1)] != x[bootnumber + 1],
                                             na.rm = TRUE)}), na.rm = TRUE)
    ## Recall that geSignature does NOT
    ## return the resubstitution error, but an
    ## error which is the mean of cross-validations.

    if(method == "dlda") 
        full.pred <- .C("dlda", as.double(wholeSampleSignt$components.scores),
                        as.integer(y),
                        as.integer(as.vector(table(y))),
                        as.double(t(wholeSampleSignt$components.scores)),
                        as.integer(max(y) - min(y) + 1),
                        as.integer(N),
                        as.integer(ncol(wholeSampleSignt$components.scores)),
                        as.integer(N),
                        predictions = as.integer(rep(-9, N)), PACKAGE = "geSignatures")$predictions
    else if(method == "knn")
        full.pred <- knn(wholeSampleSignt$components.scores,
                         wholeSampleSignt$components.scores,
                         y, k.knn)

    resubst <- mean(full.pred != y)
#    if(mean(full.pred != y) != resubst)
#        stop("resubst != prediction.error. This should never happen")
   
    ## The following code I take directly from the function
    ## bootest.factor, by Torsten Hothorn, in package ipred.
    err632 <- 0.368 * resubst + 0.632 * one
    
    gamma <-
        sum(outer(y, full.pred, function(x, y) ifelse(x == y, 0, 1)))/(length(y)^2)
    
    r <- (one - resubst)/(gamma - resubst)

    r <- ifelse(one > resubst & gamma > resubst, r, 0)
    if((r > 1) | (r < 0)) {
        print("WARNING: ************++ r out of range *******")
        print(paste("r:", r, "; gamma:", gamma, "; resubst:", resubst, "; one", one))
        print("Truncating r to ensure within appropriate range")
        if(r > 1) r <- 1
        else if(r < 0) r <- 0
    }
    
    errprime <- min(one, gamma)

    err <- err632 + (errprime - resubst) * (0.368 * 0.632 * 
            r)/(1 - 0.368 * r)
    cat("\n     632+ prediction error ")
    cat(round(err, 4))
    cat("\n")
    
    return(list(bootstrap.pred.error = err,
                model.all.data = wholeSampleSignt,
                bootstrapped.models = bootstrapped.models,
                overlap.genes = overlap.genes,
                overlap.genes.out = overlap.genes.out,
                ubiquitous.genes = ubiquitous.genes,
                mean.percentage.common.genes = mean.percentage))
    ##xx: prepare nice print and summary methods
}


### common.genes not exported
common.genes <- function(boot.models, freq.threshold = 0.5){
    number.of.sets <- length(boot.models)
    all.genes <- sapply(boot.models, function(x)
        return(unlist(x$components.with.genes)))
    table.genes <- table(unlist(all.genes))/number.of.sets
    common.genes <- as.numeric(names(table.genes[table.genes >= freq.threshold]))
    return(common.genes)
}

signtBootCommonGenes <- function(bootSigntObject, freq.threshold = 0){

    ## for the bootstrapped models
    number.of.sets <- length(bootSigntObject$bootstrapped.models)
    all.genes <- sapply(bootSigntObject$bootstrapped.models, function(x)
        return(unlist(x$components.with.genes)))
    table.genes <- table(unlist(all.genes))/number.of.sets
    table.genes <- sort(table(unlist(all.genes)), decreasing = TRUE)/number.of.sets

    table.genes.also.whole <-
        table.genes[which(rownames(table.genes) %in%
                          unlist(bootSigntObject$model.all.data$components.with.genes))]

    out <- list(table.genes[table.genes >= freq.threshold],
             table.genes.also.whole[table.genes.also.whole >= freq.threshold])
    names(out) <- c("Common genes in bootstrapped data sets",
                    "Common genes in bootstrapped data sets also in whole sample")
    return(out)
}

signtBootComponentsSummary <- function(bootSigntObject) {
    boot.models <- bootSigntObject$bootstrapped.models
    tmp1 <- t(sapply(boot.models, function(x)
                   return(c(length(unlist(x$components.with.genes)),
                            length(x$components.with.genes)))
                   ))
    tmp1 <- data.frame(tmp1)
    colnames(tmp1) <- c("TotalNumberGenes", "NumberComponents")
    tmp1$MeanNumGenesPerComponent <- tmp1[, 1]/tmp1[, 2]
    return(tmp1)
}


### collapse.signatures not exported    
collapse.signatures <- function(initial.list) {
    ## we pass a list with signatures;
    ## we return another list, where
    ## all signatures with any common element
    ## are merged

    consensus.sign <- list()
    keep.moving.along <- TRUE

    i <- 1
    while(length(initial.list)) {
        consensus.sign[[i]] <- initial.list[[1]]
        initial.list <- initial.list[-1]
        
        if(length(initial.list))
            keep.iterating <- TRUE
        
        while(keep.iterating) {
            positive.intersect <- sapply(initial.list, function(x) {
                length(intersect(consensus.sign[[i]], x))})
            lpi <- sum(positive.intersect)
            positive.intersect <- which(positive.intersect > 0)
            if(!lpi) {
                keep.iterating <- FALSE
                break
            }
            to.merge <- initial.list[positive.intersect]
            consensus.sign[[i]] <- union(consensus.sign[[i]],
                                         unlist(to.merge))
            initial.list <- initial.list[-positive.intersect]
            if(!length(initial.list)) keep.iterating <- FALSE
        }
        i <- i + 1
    }
    return(consensus.sign)
}

### common.signatures not exported
common.signatures <- function(boot.models, common.genes) {
    
    ## Takes a single list that contains, as lists
    ## all the signatures
    ## Takes the vector with the genes
    ## that are common to all bootstrap replicates

    ## take all signatures, eliminate upper level, and
    ## leave only those that have genes that are among the
    ## common genes
    if(length(common.genes)) {
        l1 <- sapply(boot.models, function(x) return(x$components.with.genes))

        tmp <- unlist(l1, recursive = FALSE)
        if (is.list(tmp)) l1 <- tmp 
##        l1 <- unlist(l1, recursive = FALSE)
        l1 <- lapply(l1, function(x)
                 {if (any (x %in% common.genes))
                      return(x[x %in% common.genes])
                 else x <- NULL})
        
        l1b <- l1[!sapply(l1, is.null)]
        l1b <- lapply(l1b, sort)
        l2 <- unlist(sapply(l1b, function(x) {if(length(x)) return(paste(x, collapse = "&"))}))
        
        ## collapse signatures with common elements
        consensus.signatures <- collapse.signatures(l1b)

        common.sign. <- l1b
        table.signatures <- table(l2)
        
     }
    else {
        common.sign. <- list()
        table.signatures <- list()
        consensus.signatures <- list()
    }
    return(list(common.sign. = common.sign.,
                table.signatures = table.signatures,
                consensus.signatures = consensus.signatures))    
}


  

################  All the following are exported


geSignature.control <- function(filter.threshold = 2,
                                    knumber = 5,
                                    k.knn = 1,                                              
                                    prefilter = TRUE,
                                    min.subset.nonpar.cor = NULL,
                                    ...) {

    if (filter.threshold <= 0)
        stop("Invalid value for filter.threshold")
    if (knumber <= 1|knumber%%1)
        stop("Invalid number of class")
    if (k.knn <= 0|k.knn%%1)
        stop("Invalid number of neigbours")
    list(filter.threshold = filter.threshold,
         knumber = knumber,
         k.knn = k.knn,         
         prefilter = prefilter,
         min.subset.nonpar.cor = min.subset.nonpar.cor)
}    




geSignature <- function(covariates, cll,
                               verbose = TRUE,
                               min.subset.cor = 0.65,
                               min.var.axis.cor = 0.8,
                               method = "dlda",
                               se.pred.new.signature = 1,
                               se.pred.new.gene = -1, 
                               control,   
                               max.signature.comps = 30) {

    if(verbose & (getOption("width") < 125))
        warning("If running with verbose = TRUE you are suggested to set width to at least 125")
    ## make sure cll is a numeric vector of consecutive
    ## integers starting at 0
    cll <- as.numeric(factor(cll)) - 1

    if (missing(control))
        control <- geSignature.control()
    else{
            if (control$filter.threshold <= 0)
                stop("Invalid value for filter.threshold")
            if (control$knumber <= 1|control$knumber%%1)
                stop("Invalid number of class")
            if (control$k.knn <= 0|control$k.knn%%1)
                stop("Invalid number of neigbours")
    }    
    
    if(is.null(control$min.subset.nonpar.cor))
        control$min.subset.nonpar.cor <- min.subset.cor
        
    if(method == "dlda") pred.newdata.error <- dlda.pred.newdata.error
    else if(method == "knn") pred.newdata.error <- knn.pred.newdata.error
    else stop("For now method can only be dlda or knn")

    f2 <- function(index.select, cll) {
        produce.cv.sample <- FALSE
        tmp2 <- table(index.select, cll)
        for(mm in 1:control$knumber) {
            tmp3 <- as.vector(apply(tmp2[-mm, , drop = FALSE], 2, sum))
            if((length(tmp3) < 2) | (min(tmp3) < 1)) {
                ## Note that the dlda method can deal with classes of size 1.
                produce.cv.sample <- TRUE
                break
            }
        }
        return(produce.cv.sample)
    }
    
    N <- length(cll)    
    last.prediction.error <- c(N, 0) ## To make sure the thing gets going
    nk <- as.vector(table(cll)) ## Number of subjects in each class
    
    if(dim(covariates)[2]) genes.to.consider <- seq(1:ncol(covariates))
    else stop("Covariates should have at least 1 column")

    if(control$prefilter) {
        ### Need to eliminate constant genes
        max.min <- apply(covariates, 2, function(x) max(x) - min(x))
        which.constant <- which(max.min == 0)
        if(length(which.constant)) {
            genes.to.consider <- genes.to.consider[-which.constant]
            if(verbose) cat("\n There were", length(which.constant), "constant gene(s)\n")
        }
        tmp <- mt.maxT(t(covariates[, genes.to.consider]), cll, B = 1, test = "f")[, c(1,2)]
        filtered <- tmp[tmp[,2] > control$filter.threshold, 1]
        genes.to.consider <- genes.to.consider[filtered]
        n <- length(genes.to.consider)
        if(!n) stop("No genes above control$filter.threshold")
        cat("\n PREFILTERING: Number of genes left after filtering is",
            n, ".\n","              ",
            ncol(covariates) - n,
            "genes excluded.\n\n")
    }
    covariates <- scale(covariates, center = TRUE, scale = FALSE)

    
    included.genes <- list()
    current.signature <- 0
    find.new.signature <- TRUE
    scores.of.signatures <- matrix(ncol = 0, nrow = N)
    percent.var.components <- vector()
    
    while(find.new.signature) {
        current.signature <- current.signature + 1
        if(verbose) cat(paste("\n   ******Searching for a new signature****; signature",
                                current.signature, "\n"))
        if(current.signature > max.signature.comps) {
            warning("Maximum number of signatures reached")
            break
        }

        ## Get the gene that will be the "seed" of the signature

        prediction.error <- matrix(-9,nrow = length(genes.to.consider),ncol = 2)
        
        if(verbose) cat(paste("\n Searching for signature seed of signature",
                        current.signature, "\n"))
        
        if (current.signature == 1) {
            ## First, we use resubstitution error which is faster,
            ## and later will use CV for finer selection among the best.
            prediction.error[,1] <- 
                apply(covariates[, genes.to.consider, drop = FALSE], 2,
                      function(x)
                      pred.newdata.error(ls = x,
                                         cll = cll,
                                         newcovar = x,
                                         newcll = cll,
                                         nk = nk,
                                         k.knn = control$k.knn))

            prediction.error[,2] <- sqrt(prediction.error[,1]*(1-prediction.error[,1])/N)
            
            error.max.bet <- 1 - (max(nk)/N)            
            pis <- nk/N            
            error.random.bet <- 1 - (sum(pis^2))
            
            if(verbose) {
                cat("\n Summary of cv errors\n")
                print(summary(prediction.error[, 1]))
                cat(paste("\nIf always betting on most common, error is", error.max.bet, "\n"))
                cat(paste("If betting randomly (with observed freq.), error is", error.random.bet, "\n\n"))
            }

            if(control$prefilter) {
                position.genes.worse.random <-
                    which((prediction.error[, 1] >=
                           min(error.max.bet, error.random.bet)))
                if(length(position.genes.worse.random)) {
                    genes.to.consider <- genes.to.consider[-position.genes.worse.random]
                    prediction.error <- prediction.error[-position.genes.worse.random, ,drop = FALSE]
                }
                cat("\n PREFILTERING STEP 2: Number of genes left after filtering is",
                length(genes.to.consider), ".\n","                      ",
                length(position.genes.worse.random),
                "genes excluded because worse than random.\n\n")                            
                if(!length(genes.to.consider)) stop("No gene has predictive capacity better than random")
            }

        }
        else {
            ## First, we use resubstitution error which is faster,
            ## and later will use CV for finer selection among the best.
            prediction.error[,1] <-
                apply(covariates[, genes.to.consider, drop = FALSE], 2,
                      function(x)            
                      pred.newdata.error(ls = cbind(scores.of.signatures, x),
                                         cll = cll, 
                                         newcovar = cbind(scores.of.signatures, x),
                                         newcll = cll,
                                         nk = nk,
                                         k.knn = control$k.knn))
            
            prediction.error[,2] <- sqrt(prediction.error[,1]*(1-prediction.error[,1])/N)                              

            if (verbose){
                cat("Summary of cross validated prediction errors for all genes\n")
                print(summary(prediction.error[, 1]))
                cat(paste("\nLast error", last.prediction.error[1], "\n"))
            }
        }
        ## We are done with all the resubstitution error-based businness.
        ## If there are genes with resubstitution error rate of 0,
        ## we will use cross-validation to select among those;
        ## otherwise, we will use cross-validation to select
        ## among the 10 with smallest resubstitution error.
        
        candidates.seed.gene <- genes.to.consider[prediction.error[ ,1] == 0]
        if (!length(candidates.seed.gene))
            candidates.seed.gene <- genes.to.consider[order(prediction.error[ ,1])[1:10]]
        
        produce.cv.sample <- TRUE
        while(produce.cv.sample) {
            index.select <-
                sample(rep(1:control$knumber, length = N), N,
                       replace = FALSE)## Code from Venables & Ripley, S Programming, p. 175.
            ## Make sure at least two classes in the training sets
            produce.cv.sample <- f2(index.select, cll)
        }

        candidates.error <- matrix(-9, nrow = length(candidates.seed.gene), ncol = control$knumber)
        for(sample.number in 1:control$knumber) {
            train.class <- cll[index.select != sample.number]
            candidates.error[, sample.number] <-
                apply(covariates[, candidates.seed.gene, drop = FALSE], 2,
                      function(x)
                      pred.newdata.error(ls = cbind(scores.of.signatures,x)[index.select != sample.number,, drop = FALSE], 
                                         cll = train.class,
                                         newcovar =
                                         cbind(scores.of.signatures,x)[index.select == sample.number,, drop = FALSE],
                                         newcll = cll[index.select == sample.number],
                                         nk = as.vector(table(train.class)),
                                         k.knn = control$k.knn))
        }
        candidates.error <- t(apply(candidates.error, 1,
                            function(x) {
                            return(c(mean(x), sqrt(var(x)/control$knumber)))}))


        if(min(candidates.error[, 1]) >=
            last.prediction.error[1] - se.pred.new.signature * last.prediction.error[2]) {
            find.new.signature <- FALSE
            break
        }
        
        minimo <- which.min(candidates.error[, 1])            
        last.prediction.error <- candidates.error[minimo, ]            

        
        ############ The intrasignature part ##########################

        seed.gene <- candidates.seed.gene[minimo]
        if(verbose) cat("\n   The seed gene is",
                    seed.gene, "\n")            

        genes.to.consider <- setdiff(genes.to.consider,seed.gene)      
                        
        percent.var.components <- c(percent.var.components, 1) 

        if(!length(genes.to.consider))  ## We are done: no genes left
            find.new.signature <- FALSE
        else { ## There are genes to consider
            ## We use both Pearson and Spearman
            ## correlation with seed gene
            initial.cor <- cbind(as.vector(genes.to.consider),
                                 t(cor(covariates[, seed.gene],
                                       covariates[, genes.to.consider])),
                                 t(cor(covariates[, seed.gene],
                                       covariates[, genes.to.consider],
                                       method = "spearman")))
                                 
            ## Eliminate all genes that show correlations
            ## of different sign
            if(verbose)
                cat(paste("   Number of genes before any elimination",
                            dim(initial.cor)[1], "\n"))
            initial.cor <- cbind(initial.cor, sign(initial.cor[, 2]) * sign(initial.cor[, 3]))
            initial.cor <- initial.cor[initial.cor[, 4] > 0, c(1, 2, 3), drop = FALSE]
            if(verbose)
                cat(paste("   Number of genes after sign coherence of correlation",
                            dim(initial.cor)[1], "\n"))
            initial.cor[, 2] <- abs(initial.cor[, 2])
            initial.cor[, 3] <- abs(initial.cor[, 3])

            initial.cor <-
                initial.cor[(initial.cor[, 2] > min.subset.cor)
                            & (initial.cor[, 3] > control$min.subset.nonpar.cor),
                            , drop = FALSE]
            if(verbose)
                cat(paste("   Number of genes after elim. not high cor",
                            dim(initial.cor)[1], "\n"))
            subset.current.signature <- c(seed.gene, initial.cor[, 1])
            
            if(length(subset.current.signature) > 1)
                the.pca <-
                    customPrcomp(covariates[, subset.current.signature, drop = FALSE])
            else {## if only one gene, no need for PCA
                the.pca <- c(1, covariates[, subset.current.signature])
                cor.scores <- 1
            }
            
            ## Make all vars correlate with 1st PC.
            if(length(subset.current.signature) > 1)
                cor.scores <- t(abs(cor(the.pca[-1],
                                        covariates[, subset.current.signature])))
            any.cors.not.ok <- any(cor.scores < min.var.axis.cor)

            if(verbose) {
                iteration <- 1
                cat("\n-----Getting all genes to correlate highly with 1st PC\n")
                cat(paste("Min correlation with PC", round(min(cor.scores), 3),
                          " on gene ",
                          subset.current.signature[which.min(cor.scores)]), "\n")
            }
            while(any.cors.not.ok) {
                if(verbose) {
                    cat(paste("......... iteration", iteration))
                    iteration <- iteration + 1
                }
                position.gene.to.drop <- which.min(initial.cor[, 2])
                gene.to.drop <- initial.cor[position.gene.to.drop, 1]
                subset.current.signature <-
                    setdiff(subset.current.signature, gene.to.drop)
                the.pca <-
                    customPrcomp(covariates[, subset.current.signature])
                ## Hey, this is inneficient: can get the correlation
                ## multiplying sdev by rotation or loadings;
                ## see Morrison, p. 317.
                cor.scores <- t(abs(cor(the.pca[-1],
                                        covariates[, subset.current.signature])))
                if(verbose)
                    cat(paste("; min correlation with PC", round(min(cor.scores), 3),
                              " on gene ",
                              subset.current.signature[which.min(cor.scores)],
                              "after dropping gene ", gene.to.drop,
                              "with cor. with seed ", round(min(initial.cor[, 2]), 3),
                              "\n"))
                initial.cor <- initial.cor[-position.gene.to.drop, , drop = FALSE]
                any.cors.not.ok <- any(cor.scores < min.var.axis.cor)
            } ## All cors with 1st PC are OK

            if(verbose) {
                print("Cor with 1st PC and loadings:  ")
                print(data.frame(subset.current.signature,
                                 cor.1st.PC = t(cor(the.pca[-1],
                                 covariates[, subset.current.signature])),
                                 loadings = prcomp(covariates[, subset.current.signature])$rotation[,1]))
            }
            
            ## Reduction as a function of predictive capacity
            ## We use CV to judge prediction.
            if(verbose) cat("\n-----Reducing signature using prediction error")

            if(length(subset.current.signature) > 1) {
                current.signature.no.seed <- setdiff(subset.current.signature,
                                                     seed.gene)
                                                     
                examine.drop1 <- TRUE

                whole.signature.error <-
                    internal.cv.pred.error(scores.of.signatures[, , drop = FALSE],
                                           covariates[, subset.current.signature, drop = FALSE],
                                           cll, knumber = control$knumber,
                                           method = method, k.knn = control$k.knn) 
               
                if(verbose) cat(paste("\n    Complete model; Prediction Error",
                                      whole.signature.error[1], "s.e.", whole.signature.error[2], "\n"))

            } ## if(length(subset ....)
            else { ## No components in signature, except seed gene
                examine.drop1 <- FALSE
                current.signature.no.seed <- NULL
                whole.signature.error <- last.prediction.error
                if(verbose) cat("\n    Nothing to examine: only one component in signature\n")
            }


            while(examine.drop1) {
                drop1.signature.error <- matrix(-9, nrow = length(current.signature.no.seed),
                                                ncol = 2)
                for(i in 1:length(current.signature.no.seed)) {
                    drop1.subset <- setdiff(subset.current.signature,
                                            current.signature.no.seed[i])
                        
                    drop1.signature.error[i, ] <-
                        internal.cv.pred.error(scores.of.signatures[, , drop = FALSE],
                                               covariates[, drop1.subset, drop = FALSE],
                                               cll, knumber = control$knumber,
                                               method = method, k.knn = control$k.knn)
                                       
                    if(verbose) cat(paste("........  drop1; step", i, "; -gene ",
                                          current.signature.no.seed[i],
                                          "; Pred. Error: mean", drop1.signature.error[i, 1],
                                          "s.e.", round(drop1.signature.error[i, 2], 4),"\n"))
                }

                if(min(drop1.signature.error[, 1]) <
                   (whole.signature.error[1] + se.pred.new.gene * whole.signature.error[2])) {
                    if(verbose) cat(paste("Dropped gene",
                                          current.signature.no.seed[which.min(drop1.signature.error[, 1])],
                                          "\n"))
                    current.signature.no.seed <-
                        current.signature.no.seed[-which.min(drop1.signature.error[, 1])]
                    whole.signature.error <-
                        drop1.signature.error[which.min(drop1.signature.error[, 1]),]
                    if(!length(current.signature.no.seed)) examine.drop1 <- FALSE
                } else examine.drop1 <- FALSE
            } ## No further increases in predictive capacity
            
            genes.current.signature <- c(seed.gene, current.signature.no.seed)
            included.genes[[current.signature]] <-
                genes.current.signature
            genes.to.consider <-
                setdiff(genes.to.consider,  genes.current.signature)
            this.signature <- customPrcomp(covariates[, genes.current.signature, drop = FALSE])
            scores.of.signatures <- cbind(scores.of.signatures, this.signature[-1])
            percent.var.components[current.signature] <- this.signature[1]
            last.prediction.error <- whole.signature.error
        } ## There were genes to consider
        
        if(!length(genes.to.consider)) {
            ## We are done: no genes left
            find.new.signature <- FALSE
        }
    }## while(find.new.signature)
        
    y <- list(components.with.genes = included.genes,
              components.scores = scores.of.signatures,
              percent.var.components = percent.var.components,
              prediction.error = c(mean = last.prediction.error[1],
              s.e. = last.prediction.error[2]),
              corr.components = cor(scores.of.signatures)
              )
    class(y) <- "geSignt"
    return(y)   
}




print.geSignt <- function(x, ndec = 2, ...){
    cat("\n")
    cat("Signatures with genes \n")
    print(x$components.with.genes)
    cat("\n")
    cat("Variance (percent) \n")
    print(x$percent.var.components)
    cat("\n\n")
    cat("(~Resubstitution) Prediction errors \n")
    print(x$prediction.error)
    cat("\n\n")
    cat("Components' correlation \n")
    print(round(x$corr.components,ndec))
    cat("\n\n\n")
    invisible(x)
}


summary.geSignt <- function(object, return.components.scores = TRUE, ...){
    class(object) <- "summary.geSignt"
    if(!return.components.scores)
      object$components.scores <- NULL
    return(object)
}

print.summary.geSignt <-function(x, ...){
    cat("\n")
    cat("Number of components \n")
    print(length(x$components.with.genes))
    cat("\n\n")
    cat("Genes per signature component \n")
    print(lapply(x$components.with.genes, length))
    cat("\n")
    cat("Variance (percent) \n")
    print(x$percent.var.components)
    cat("\n\n")
    cat("(~Resubstitution) Prediction errors \n")
    print(x$prediction.error)
    cat("\n\n")
    cat("Components' correlation \n")
    print(round(x$corr.components, 3))
    cat("\n\n")
    if (length(x$components.scores)){
        cat("Signature components scores \n")
        print(x$components.scores)
    }
    cat("\n\n\n")
    invisible(x)
}
